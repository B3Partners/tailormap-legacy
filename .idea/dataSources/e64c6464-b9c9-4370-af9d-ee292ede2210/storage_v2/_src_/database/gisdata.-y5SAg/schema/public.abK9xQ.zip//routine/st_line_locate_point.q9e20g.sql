create function st_line_locate_point(geom1 geometry, geom2 geometry)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT public._postgis_deprecate('ST_Line_Locate_Point', 'ST_LineLocatePoint', '2.1.0');
     SELECT public.ST_LineLocatePoint($1, $2);
$$;

