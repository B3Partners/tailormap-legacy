create function st_coveredby(geom1 geometry, geom2 geometry)
  returns boolean
immutable
parallel safe
language sql
as $$
SELECT $1 @ $2 AND public._ST_CoveredBy($1,$2)
$$;

