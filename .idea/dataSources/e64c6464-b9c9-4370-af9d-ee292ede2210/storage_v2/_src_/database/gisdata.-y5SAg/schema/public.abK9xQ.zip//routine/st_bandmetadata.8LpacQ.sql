create function st_bandmetadata(rast raster, band integer DEFAULT 1, OUT pixeltype text, OUT nodatavalue double precision, OUT isoutdb boolean, OUT path text)
  returns record
immutable
strict
parallel safe
language sql
as $$
SELECT pixeltype, nodatavalue, isoutdb, path FROM public.ST_BandMetaData($1, ARRAY[$2]::int[]) LIMIT 1
$$;

