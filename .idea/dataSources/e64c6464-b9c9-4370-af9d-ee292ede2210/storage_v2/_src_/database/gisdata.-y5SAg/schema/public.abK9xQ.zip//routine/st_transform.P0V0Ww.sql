create function st_transform(geom geometry, from_proj text, to_proj text)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT postgis_transform_geometry($1, $2, $3, 0)
$$;

