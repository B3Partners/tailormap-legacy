create function postgis_scripts_build_date()
  returns text
immutable
language sql
as $$
SELECT '2016-12-19 00:17:51'::text AS version
$$;

