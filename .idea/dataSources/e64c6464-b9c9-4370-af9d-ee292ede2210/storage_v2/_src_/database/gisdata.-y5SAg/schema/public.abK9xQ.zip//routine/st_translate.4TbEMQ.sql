create function st_translate(geometry, double precision, double precision)
  returns geometry
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_Translate($1, $2, $3, 0)
$$;

