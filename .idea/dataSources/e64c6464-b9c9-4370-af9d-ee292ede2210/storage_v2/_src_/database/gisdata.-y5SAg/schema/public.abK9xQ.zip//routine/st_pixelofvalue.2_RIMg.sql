create function st_pixelofvalue(rast raster, search double precision, exclude_nodata_value boolean DEFAULT true, OUT x integer, OUT y integer)
  returns SETOF record
immutable
strict
parallel safe
language sql
as $$
SELECT x, y FROM public.ST_pixelofvalue($1, 1, ARRAY[$2], $3)
$$;

