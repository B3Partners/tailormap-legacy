create function overlaps_geog(geography, gidx)
  returns boolean
immutable
strict
language sql
as $$
SELECT $2 OPERATOR(public.&&) $1;
$$;

