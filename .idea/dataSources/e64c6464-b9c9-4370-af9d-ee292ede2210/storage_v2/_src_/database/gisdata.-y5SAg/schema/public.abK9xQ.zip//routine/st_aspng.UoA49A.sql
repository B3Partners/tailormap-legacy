create function st_aspng(rast raster, nbands integer[], options text[] DEFAULT NULL::text[])
  returns bytea
immutable
parallel safe
language sql
as $$
SELECT st_aspng(st_band($1, $2), $3)
$$;

