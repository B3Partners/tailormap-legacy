create function checkauth(text, text)
  returns integer
language sql
as $$
SELECT CheckAuth('', $1, $2)
$$;

