create function st_rotation(raster)
  returns double precision
language sql
as $$
SELECT ( public.ST_Geotransform($1)).theta_i
$$;

