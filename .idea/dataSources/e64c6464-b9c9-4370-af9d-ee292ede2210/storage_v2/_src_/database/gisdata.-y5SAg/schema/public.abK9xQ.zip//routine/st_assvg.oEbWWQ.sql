create function st_assvg(text)
  returns text
immutable
strict
parallel safe
language sql
as $$
SELECT ST_AsSVG($1::public.geometry,0,15);
$$;

