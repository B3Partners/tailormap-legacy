create function st_rastertoworldcoordy(rast raster, xr integer, yr integer)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT latitude FROM public._ST_rastertoworldcoord($1, $2, $3)
$$;

