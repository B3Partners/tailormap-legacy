create function st_quantile(rast raster, quantiles double precision[], OUT quantile double precision, OUT value double precision)
  returns SETOF record
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_quantile($1, 1, TRUE, 1, $2)
$$;

