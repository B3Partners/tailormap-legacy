create function st_band(rast raster, nbands text, delimiter character DEFAULT ','::bpchar)
  returns raster
immutable
strict
parallel safe
language sql
as $$
SELECT  public.ST_band($1, regexp_split_to_array(regexp_replace($2, '[[:space:]]', '', 'g'), E'\\' || array_to_string(regexp_split_to_array($3, ''), E'\\'))::int[])
$$;

