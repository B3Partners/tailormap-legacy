create function st_buffer(geography, double precision)
  returns geography
immutable
strict
parallel safe
language sql
as $$
SELECT geography(ST_Transform(ST_Buffer(ST_Transform(geometry($1), public._ST_BestSRID($1)), $2), 4326))
$$;

