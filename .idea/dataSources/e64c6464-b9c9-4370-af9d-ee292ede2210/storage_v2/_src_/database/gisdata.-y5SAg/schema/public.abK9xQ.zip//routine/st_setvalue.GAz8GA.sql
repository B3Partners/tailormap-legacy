create function st_setvalue(rast raster, nband integer, geom geometry, newvalue double precision)
  returns raster
immutable
parallel safe
language sql
as $$
SELECT public.ST_setvalues($1, $2, ARRAY[ROW($3, $4)]::geomval[], FALSE)
$$;

