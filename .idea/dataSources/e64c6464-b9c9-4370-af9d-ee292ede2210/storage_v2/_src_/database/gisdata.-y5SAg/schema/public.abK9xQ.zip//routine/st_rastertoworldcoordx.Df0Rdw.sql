create function st_rastertoworldcoordx(rast raster, xr integer)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT longitude FROM public._ST_rastertoworldcoord($1, $2, NULL)
$$;

